import view.GamaView;

public class Main {
    public static void main(String[] args) {
        GamaView vista = new GamaView();
        vista.menuprincipal();
    }
}
